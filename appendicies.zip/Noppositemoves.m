upperlimit = 10000;
maxmoves = 25;
draw = 0;
P1W = 0;
P2W = 0;
for loop1 = 1:upperlimit
    N = loop1;
    for loop2 = 1:(maxmoves/2)
        if floor(sqrt(N))==sqrt(N)
            P1W = P1W + 1;
            N = 0;
            break
        else
            N = N + floor(sqrt(N))^2;
        end
        if floor(sqrt(N))==sqrt(N)
            P2W = P2W + 1;
            N= 0;
            break
        else
            N = N - floor(sqrt(N))^2;
        end
    end
        if N ~= 0
            draw = draw+1;
        end
end

