A = P1W;
n = length(A);
xaxis = [1:n];
plot(xaxis, A)