maxiterations = 2; %maximum number of iterations
upperlimit = 100000; %upper limit of numbers we are testing
alpha = 100; %arbitrary limit to ensure we see majority of possible outcomes
P1W = [-1]; %vector to store all the winning positions for player 1
P2W = []; %vector to store all the winning positions for player 2
turn = -2; % a variable to record which players turn it is
startingnumbers = 1:alpha*upperlimit; %sets the range of numbers we are looking at
testnumbers = startingnumbers; %sets the numbers we are testing
for loop = 1:length(testnumbers) 
    x = testnumbers(loop); %saves current number to make calculations easier
    if floor(sqrt(x)) == sqrt(x) %checks if number is square
        P1W = [P1W, x]; %stores all the winning positions for player 1
    end
end

count = 1;

while count < length(testnumbers) %deletes all the entries we have found that are into a group
    if ismember(testnumbers(count), P1W)
        testnumbers(count) = [];
    end
    count = count + 1;
end
iteration = 2; %records we did the first iteration
while iteration < maxiterations
    P2W = [P2W, turn];%records which turn we saw the numbers
    for loop = 1:length(testnumbers)
        A = testnumbers(loop); %pulls the number we are checking
        squarebelow = (floor(sqrt(A)))^2; %finds the square number that is below our test number
        A1 = A + squarebelow;
        A2 = A - squarebelow; %adds and subtracts the square below A
        if and(ismember(A1, P1W), ismember(A2, P1W)) %checks if both of the numbers go to a win
            if ismember((A/A2),P2W) %makes sure the number we found is a primitive element
            else
                P2W = [P2W, A]; %saves the number as a winning position
            end
        end
    end
    iteration = iteration + 1; %counts on an iteration
    count = 1; %resets the variable
    
    while count < length(testnumbers) %deletes all the entries we have found that are into a group
        if ismember(testnumbers(count), P2W)
            testnumbers(count) = []; %deletes the entry if needed
        end
        count = count + 1; %counts on
    end
    turn = turn - 1; %records a turn has passed
    P1W = [P1W, turn];%records which turn we saw the numbers
    for loop = 1:length(testnumbers)
        A = testnumbers(loop); %pulls the number we are checking
        squarebelow = (floor(sqrt(A)))^2; %finds the square number that is below our test number
        A1 = A + squarebelow;
        A2 = A - squarebelow; %adds and subtracts the square below A
        if or(ismember(A1, P2W), ismember(A2, P2W)) %checks if one of the numbers go to a win
            P1W = [P1W, A]; %saves the number as a winning position
        end
    end
    
    count = 1; %resets the variable
    
    while count < length(testnumbers) %deletes all the entries we have found that are into a group
        if ismember(testnumbers(count), P1W)
            testnumbers(count) = []; %deletes the entry if needed
        end
        count = count + 1; %counts on
    end
    turn = turn - 1; %records a turn has passed
    iteration = iteration + 1; %counts on an iteration
end
if iteration == maxiterations %if we need an extra layer to be computed
    P2W = [P2W, turn];%records which turn we saw the numbers
    for loop = 1:length(testnumbers)
        A = testnumbers(loop); %pulls the number we are checking
        squarebelow = (floor(sqrt(A)))^2; %finds the square number that is below our test number
        A1 = A + squarebelow;
        A2 = A - squarebelow; %adds and subtracts the square below A
        if and(ismember(A1, P1W), ismember(A2, P1W)) %checks if both of the numbers go to a win
            if ismember((A/A2),P2W) %makes sure the number we found is a primitive element
            else
                P2W = [P2W, A]; %saves the number as a winning position
            end
        
        end
    end
    iteration = iteration + 1; %counts on an iteration
    count = 1; %resets the variable
    while count < length(testnumbers) %deletes all the entries we have found that are into a group
        if ismember(testnumbers(count), P2W)
            testnumbers(count) = []; %deletes the entry if needed
        end
        count = count + 1;
    end
end
%disp('The overall final positions, where negative numbers designate the turns the numbers were found, starting from player 1')
%a nice line to explain what my output is showing
P1W;
P2W;