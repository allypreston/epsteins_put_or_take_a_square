for loop = 2:length(P2W)
    P2W(loop) - floor(sqrt(P2W(loop)))^2
end