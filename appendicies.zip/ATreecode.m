function Treecode(N, maxmoves)
storage = []; %a vector to store all the positions we have seen and which turn we saw them
newnumbers = []; % a vector to store all new numbers seen that round
testnumbers = []; % a vector to record all numbers to be tested
P1W = []; %record of all winning positions by player 1
P2W = []; %record of all winning positions by player 2
D = []; %record of all drawing positions
other = []; %record of all positions that are too far in the loop
turn = 1; %A variable to record the turn number
player = 1; %which player is going
square = 0; %records the number of squares per branch
draw = 0; %records the number of drawing positions
nodecounter = 1; %a variable to work with the tree display
t = tree(N); %begins a tree at our starting number
if sqrt(N) == floor(sqrt(N)) %checks if N is an exact square
    P1W = [N 1]; %Player 1 wins immediately 
else
    testnumbers = [N]; %adds the number to the testing box
end
    while maxmoves > 0 %makes sure that the program doesnt get stuck
        for k = 1:length(testnumbers) % tests all the numbers in the test box
            A = testnumbers(k); %fetches the variable to work as the lower square
            if ismember(A,storage)
            else
            squarebelow = (floor(sqrt(A)))^2; %finds the square number that is below our test number
            A1 = A + squarebelow;
            A2 = A - squarebelow; %adds and subtracts the square below A
            
            [t] = t.addnode(nodecounter, A1); %adds the branches to our tree
            [t] = t.addnode(nodecounter, A2);
            nodecounter = nodecounter + 1; %moves the plotting function along
            if ismember(A1, storage) %checks if we have seen this number before and can cut the branch
                draw = draw + 1;
                 storage = [storage, A1]; %adds our number into the storage                
            elseif sqrt(A1) == floor(sqrt(A1)) %checks if the number is a square
                square = square + 1;
                 storage = [storage, A1]; %adds our number into the storage
            else
                newnumbers = [newnumbers, A1]; %adds our number into the new numbers box
            end
            if ismember(A2, storage) %checks if we have seen this number before and can cut the branch
                 draw = draw + 1;
                storage = [storage, A2]; %adds our number into the storage
            elseif sqrt(A2) == floor(sqrt(A2)) %checks if the number is a square
                 square = square + 1;
                storage = [storage, A2]; %adds our number into the storage
            else
                newnumbers = [newnumbers, A2]; %adds our number into the new numbers box
            end
            if square == 2 %checks if both numbers we found are squares
                if player == 1 %checks if it is player 1's turn
                    P1W = [P1W; A turn]; %records the numbers 
                else
                    P2W = [P2W; A turn]; %records the numbers
                end
            end
            if draw == 2 %records drawn positions
                D = [D [A; turn]];
            elseif and(draw == 1, square == 1)
                D = [D [A; turn]];
            end
            stop = 0; % a variable to stop the loop going over

            while and(or(sqrt(t.get(nodecounter)) == floor(sqrt(t.get(nodecounter))),ismember(t.get(nodecounter),storage)), stop == 0)
                if and(nnodes(t) == nodecounter,maxmoves ~= 1) %makes sure that the loop doesnt get too high
                    stop = 1;
                else
                    nodecounter = nodecounter + 1; %checks if the next number in the plot is a square or a draw
                end
            end
            end
        end
        storage = [storage, testnumbers]; %stores the numbers for this round
        testnumbers = newnumbers; %moves the new numbers to now be tested
        newnumbers = []; %resets the new numbers
        player = -player; %sets the player turn to the opposite player
        turn = turn + 1; %counts on the turn
        square = 0; %resets old variables
        draw = 0;
        maxmoves = maxmoves - 1; %records we made a move
    end
close all %removes all open figures if any
%disp(t.tostring) %displays the output, not be needed but useful for
%troubleshooting
[slin] = t; %used to plot the tree in a figure window for niceish display
figure
[vlh]=slin.plot;
set(findall(gcf,'-property','FontSize'),'FontSize',25)
ylabel('turn');