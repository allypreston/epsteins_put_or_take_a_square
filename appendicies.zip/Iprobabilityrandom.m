upperlimit  = 1000; %the upper limit we are testing
iterations = 100; %number of times we will repeat each run
maxmoves = 100; %number of maximum moves
probability = 0.5; %probability of adding
n = [1:upperlimit];
p1w = 0; %sets the starting wins to zero
p2w = 0;
turnsaver = [];
expire = 0;
for repeats = 1:iterations
    for loop = n %checks each number and sees if player 1 or player 2 won
        turn = Grandomplayer(loop, maxmoves, probability);
        if turn == maxmoves %makes sure it wasnt a draw
            expire = expire+1;
        else
            if mod(turn, 2) == 1
                p1w = p1w + 1;
            else
                p2w = p2w + 1;
            end
            turnsaver = [turnsaver, turn];
        end
    end
end
p1w/p2w
histogram(turnsaver)