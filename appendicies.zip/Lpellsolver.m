for n = 1:3
    m = 0.5*((3-2*sqrt(2))^n + (3+2*sqrt(2))^n)
end
for n = 1:3
    k = (0.5/sqrt(2))*((3+2*sqrt(2))^n - (3-2*sqrt(2))^n)
end