%run numberchecker no draw, or numberchecker and locate the elements in the
%layer you are looking for, save them under the variable A
element = 10;
a = A/A(element);
count = 0;
for loop = 1:length(a)
    if floor(a(loop)) == a(loop)
        count = count+1;
    end
end
percentage = count/length(a);