function answer = Hrandomplayerwithbrain(n, maxruns)
count = 0; %sets the start
while and(n ~= 0, count < maxruns) % until the upper limit is met, or there is a winner
    if floor(sqrt(n)) == sqrt(n) %if n is a square
        n = 0; % set it to a win
    else
        n = n + (-1)^randi(2)*floor(sqrt(n))^2; %randomly adds or subtracts the square below
    end
    count = count+1; %counts on
end
count
n