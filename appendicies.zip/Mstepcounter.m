upperlimit = 1000;
turn = 0;
steps = [];
for testnumber = 1:upperlimit
    N = testnumber;
        while N > 0
            turn = turn+1;
            N = N - floor(sqrt(N))^2;
        end
    steps = [steps turn];
    turn = 0;
end
histogram(steps)