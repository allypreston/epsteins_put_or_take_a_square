clear %makes sure no left over variables are saved and filling excess parts of the code
%% - initial variables to input as wanted
maxiterations = 4; %maximum number of iterations, the number of 'layers' we are looking at
upperlimit = 1000; %upper limit of numbers we are testing
lowerlimit = 25; %removes the few first elements due to their high denstity
alpha = 100; %arbitrary limit to ensure we see majority of possible outcomes
%% - initial stores and variables to be used
P1W = []; %vector to store all the winning positions for player 1
P2W = []; %vector to store all the winning positions for player 2
Draw = []; %vector to store all the possible drawing positions
PosDraw = []; %vector to store all the numbers that might be draws but the algorithm cannot deal with
testnumbers = 1:(upperlimit*alpha); %tests all numbers up to alpha times bigger than the starting numbers
startingnumbers = testnumbers; %a record of the numbers we started with
%% - computes our first layer
for loop = 1:length(testnumbers) 
    x = testnumbers(loop); %saves current number to make calculations easier
    if floor(sqrt(x)) == sqrt(x) %checks if number is square
        P1W = [P1W, x]; %stores all the winning positions for player 1
    end
end
count = 1; %sets the variable
while count < length(testnumbers) %deletes all the entries we have found that are into a group
    if ismember(testnumbers(count), P1W)
        testnumbers(count) = [];
    end
    count = count + 1; %counts on
end
%% - runs all the iterations for as many layers as we want
iterations = 2; %records we are on the second iteration
while iterations < maxiterations
    for loop = 1:length(testnumbers)
        A = testnumbers(loop); %pulls the number we are checking
        squarebelow = (floor(sqrt(A)))^2; %finds the square number that is below our test number
        A1 = A + squarebelow;
        A2 = A - squarebelow; %adds and subtracts the square below A
        if and(ismember(A1, P1W), ismember(A2, P1W)) %checks if both of the numbers go to a win
            P2W = [P2W, A]; %saves the number as a winning position
        elseif and(ismember(A1, P1W), ismember(A2, startingnumbers))
            Draw = [Draw, A]; %saves the number as a drawing position
        elseif and(ismember(A2, P1W), ismember(A1, startingnumbers))
            Draw = [Draw, A]; %saves the number as a drawing position
        end
    end
    iterations = iterations + 1; %counts on an iteration
    count = 1; %resets the variable
    while count < length(testnumbers) %deletes all the entries we have found that are into a group
        if ismember(testnumbers(count), P2W)
            testnumbers(count) = []; %deletes the entry if needed
        end
        count = count + 1; %counts on
    end
    for loop = 1:length(testnumbers)
        A = testnumbers(loop); %pulls the number we are checking
        squarebelow = (floor(sqrt(A)))^2; %finds the square number that is below our test number
        A1 = A + squarebelow;
        A2 = A - squarebelow; %adds and subtracts the square below A
        if or(ismember(A1, P2W), ismember(A2, P2W)) %checks if one of the numbers go to a win
            P1W = [P1W, A]; %saves the number as a winning position
        end
    end
    count = 1; %resets the variable
    while count < length(testnumbers) %deletes all the entries we have found that are into a group
        if ismember(testnumbers(count), P1W)
            testnumbers(count) = []; %deletes the entry if needed
        end
        count = count + 1; %counts on
    end
    iterations = iterations + 1; %counts on an iteration
end
if iterations == maxiterations %if we need an extra layer to be computed
    for loop = 1:length(testnumbers)
        A = testnumbers(loop); %pulls the number we are checking
        squarebelow = (floor(sqrt(A)))^2; %finds the square number that is below our test number
        A1 = A + squarebelow;
        A2 = A - squarebelow; %adds and subtracts the square below A
        if and(ismember(A1, P1W), ismember(A2, P1W)) %checks if both of the numbers go to a win
            P2W = [P2W, A]; %saves the number as a winning position
        elseif and(ismember(A1, P1W), ismember(A2, startingnumbers))
            Draw = [Draw, A]; %saves the number as a drawing position
        elseif and(ismember(A2, P1W), ismember(A1, startingnumbers))
            Draw = [Draw, A]; %saves the number as a drawing position
        end
    end
    iterations = iterations + 1; %counts on an iteration
    count = 1; %resets the variable
    while count < length(testnumbers) %deletes all the entries we have found that are into a group
        if ismember(testnumbers(count), P2W)
            testnumbers(count) = []; %deletes the entry if needed
        end
        count = count + 1;
    end
end
P1W = unique(P1W); %removes duplicates for all layers
P2W = unique(P2W);
Draw = unique(Draw);
%% - reduces the found values to the ones only in the range we were looking for
P1W = P1W(P1W <= upperlimit); %saves all the values within the investigative range
P2W = P2W(P2W <= upperlimit);
Draw = Draw(Draw <= upperlimit);
P1W =  P1W(P1W > lowerlimit); %removes the first few entries due to their extremely high density
P1W =  P2W(P2W > lowerlimit);
Draw =  Draw(Draw > lowerlimit);
%% - calculates the relative densities 
density1 = [1:length(P1W)]./P1W; 
density2 = [1:length(P2W)]./P2W;
densitydraw = [1:length(Draw)]./Draw;
%% - help with approximating functions
% P1Wsmooth = smooth(P1W, 20, 'sgolay', 5); %creates smooth versions of the curves so we can see the overall function
% P2Wsmooth = smooth(P2W, 20, 'sgolay', 5);
% Drawsmooth = smooth(Draw, 20, 'sgolay', 5);
% D1smooth = smooth(density1, 20, 'sgolay', 5); 
% D2smooth = smooth(density2, 20, 'sgolay', 5);
% D3smooth = smooth(densitydraw, 20, 'sgolay', 5);
%% - plots the function(s) we want on seperate figures

figure(1); 
hold on 
plot(P1W,density1,'LineWidth', 3) %exact values plotted
%plot(P1Wsmooth, D1smooth, 'LineWidth', 3) %smooths the curves before plotting
set(gca, 'FontSize', 12)
hold off
figure(2);
hold on
plot(P2W,density2,'LineWidth', 3)
%plot(P2Wsmooth, D2smooth, 'LineWidth', 3)
set(gca, 'FontSize', 12)
hold off
figure(3);
hold on
plot(Draw,densitydraw, 'LineWidth', 3)
%plot(Drawsmooth, D3smooth, 'LineWidth', 3)
set(gca, 'FontSize', 12)
hold off