%plottest
%%
figure(1)
density1m = (log(density1)).^-1/2;
hold on
plot(P1W, density1m,'LineWidth', 3)
hold off
%%
figure(2)
density2m = (log(density2)).^-1;
hold on
plot(P2W, density2m,'LineWidth', 3)
hold off
%%
figure(3)
densitydrawm = log(densitydraw);
hold on
plot(Draw, densitydrawm,'LineWidth', 3)
hold off