maxiterations = 10; %maximum number of iterations
upperlimit = 1000; %upper limit of numbers we are testing
alpha = 100; %arbitrary limit to ensure we see majority of possible outcomes
P1W = []; %vector to store all the winning positions for player 1
P2W = []; %vector to store all the winning positions for player 2
Draw = []; %vector to store all the possible drawing positions
PosDraw = []; %vector to store all the numbers that might be draws but the algorithm cannot deal with
turn = -2; %a variable to record which turn it is
startingnumbers = 1:alpha*upperlimit; %sets the range of numbers we are looking at
testnumbers = startingnumbers; %sets the numbers we are testing
for loop = 1:length(testnumbers) 
    %P1W = [P1W turn];
    x = testnumbers(loop); %saves current number to make calculations easier
    if floor(sqrt(x)) == sqrt(x) %checks if number is square
        P1W = [P1W, x]; %stores all the winning positions for player 1
    end
end

count = 1;

while count < length(testnumbers) %deletes all the entries we have found that are into a group
    if ismember(testnumbers(count), P1W)
        testnumbers(count) = [];
    end
    count = count + 1;
end
iteration = 2; %records we did the first iteration
while iteration < maxiterations
    %P2W = [P2W, turn];%records which turn we saw the numbers
    for loop = 1:length(testnumbers)
        A = testnumbers(loop); %pulls the number we are checking
        squarebelow = (floor(sqrt(A)))^2; %finds the square number that is below our test number
        A1 = A + squarebelow;
        A2 = A - squarebelow; %adds and subtracts the square below A
        t1 = ismember(A1, P1W); %tests variables here to improve effieciency
        t2 = ismember(A2, P1W);
        if and(t1, t2) %checks if both of the numbers go to a win
            P2W = [P2W, A]; %saves the number as a winning position
         elseif and(t1, ismember(A2, startingnumbers))
             Draw = [Draw, A]; %saves the number as a drawing position
         elseif and(t2, ismember(A1, startingnumbers))
             Draw = [Draw, A]; %saves the number as a drawing position
        end
    end
    iteration = iteration + 1; %counts on an iteration
    count = 1; %resets the variable
    
    while count < length(testnumbers) %deletes all the entries we have found that are into a group
        if ismember(testnumbers(count), P2W)
            testnumbers(count) = []; %deletes the entry if needed
        end
        count = count + 1; %counts on
    end
    turn = turn - 1; %records a turn has passed
    %P1W = [P1W, turn];%records which turn we saw the numbers
    for loop = 1:length(testnumbers)
        A = testnumbers(loop); %pulls the number we are checking
        squarebelow = (floor(sqrt(A)))^2; %finds the square number that is below our test number
        A1 = A + squarebelow;
        A2 = A - squarebelow; %adds and subtracts the square below A
        if or(ismember(A1, P2W), ismember(A2, P2W)) %checks if one of the numbers go to a win
            P1W = [P1W, A]; %saves the number as a winning position
        end
    end
    
    count = 1; %resets the variable
    
    while count < length(testnumbers) %deletes all the entries we have found that are into a group
        if ismember(testnumbers(count), P1W)
            testnumbers(count) = []; %deletes the entry if needed
        end
        count = count + 1; %counts on
    end
    turn = turn - 1; %records a turn has passed
    iteration = iteration + 1; %counts on an iteration
end
if iteration == maxiterations %if we need an extra layer to be computed
    P2W = [P2W, turn];%records which turn we saw the numbers
    for loop = 1:length(testnumbers)
        A = testnumbers(loop); %pulls the number we are checking
        squarebelow = (floor(sqrt(A)))^2; %finds the square number that is below our test number
        A1 = A + squarebelow;
        A2 = A - squarebelow; %adds and subtracts the square below A
        if and(ismember(A1, P1W), ismember(A2, P1W)) %checks if both of the numbers go to a win
            P2W = [P2W, A]; %saves the number as a winning position
        elseif and(ismember(A1, P1W), ismember(A2, startingnumbers))
            Draw = [Draw, A]; %saves the number as a drawing position
        elseif and(ismember(A2, P1W), ismember(A1, startingnumbers))
            Draw = [Draw, A]; %saves the number as a drawing position
        end
    end
    iteration = iteration + 1; %counts on an iteration
    count = 1; %resets the variable
    while count < length(testnumbers) %deletes all the entries we have found that are into a group
        if ismember(testnumbers(count), P2W)
            testnumbers(count) = []; %deletes the entry if needed
        end
        count = count + 1;
    end
end

for loop = 1:length(P1W)
    if P1W(loop) > upperlimit
        P1W(loop) = 0;
    end
end
P1W(P1W == 0) = [];

for loop = 1:length(P2W)
    if P2W(loop) > upperlimit
        P2W(loop) = 0;
    end
end
P2W(P2W == 0) = []; %we then remove all numbers outside our range

PosDraw = testnumbers; %records all the numbers we didn't find a home for

P1W = unique(P1W);
P2W = unique(P2W);
Draw = unique(Draw); %orders all the drawn positions and removes duplicates

for loop = 1:length(P1W)
    if P1W(loop) > upperlimit
        P1W(loop) = 0;
    end
end
P1W(P1W == 0) = [];

for loop = 1:length(Draw)
    if Draw(loop) > upperlimit
        Draw(loop) = 0;
    end
end
Draw(Draw == 0) = [];

figure
plot(1:length(P1W), P1W)
figure
plot(1:length(P2W), P2W)
figure
plot(1:length(Draw), Draw)
PosDraw;