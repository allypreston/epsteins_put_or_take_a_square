n = length(P2W);
A = P2W(2:n); %Removes the negative entries
n = n-1;
xaxis = [1:n];
plot(xaxis, A)