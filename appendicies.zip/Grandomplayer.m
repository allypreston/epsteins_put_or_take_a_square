function count = Grandomplayer(n, maxruns, probability)
count = 0; %sets the start
while and(n ~= 0, count < maxruns) % until the upper limit is met, or there is a winner
    u = rand;
    if u < probability
        n = n + floor(sqrt(n))^2; %adds the square below
    elseif u > probability
        n = n - floor(sqrt(n))^2; %subtracts the square below
    else
      count = count - 1;
    end
    count = count+1; %counts on
end