function c = Joppositeoperations(n, maxruns)
count = 0; %sets the start
player = 1;
while and(n ~= 0, count < maxruns) % until the upper limit is met, or there is a winner
    if floor(sqrt(n)) == sqrt(n) %if n is a square
        n = 0; % set it to a win
    elseif player == 1
        n = n + floor(sqrt(n))^2; %randomly adds or subtracts the square below
        player = 2;
    elseif player == 2
        n = n - floor(sqrt(n))^2; %randomly adds or subtracts the square below
        player = 1; 
    end
    count = count+1; %counts on
end
c = player;