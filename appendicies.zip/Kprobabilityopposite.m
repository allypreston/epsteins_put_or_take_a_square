upperlimit  = 100;
iterations = 1000;
maxmoves = 1000;
n = [1:upperlimit];
p1w = 0;
p2w = 0;
for repeats = 1:iterations
    for loop = n
        player = Joppositeoperations(loop, maxmoves);
        if player == 1
            p1w = p1w + 1;
        else
            p2w = p2w + 1;
        end
    end
end
p1w/p2w